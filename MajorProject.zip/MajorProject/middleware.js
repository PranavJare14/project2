const Listing = require("./models/listing");
const Review = require("./models/review");

module.exports.isLoggedIn =(req,res,next)=>{                             //middleware for loging authenticate
    if(!req.isAuthenticated()){
        req.session.redirectUrl=req.originalUrl;
        req.flash("error","You must be login First To Create Listing!");
         return res.redirect("/login");
      }
      next();
}

module.exports.saveredirectUrl = (req,res,next)=>{                    //it use to store a login person session id
    if(req.session.redirectUrl){
        res.locals.redirectUrl=req.session.redirectUrl;
    }
    next();
};


module.exports.isowner = async ( req,res,next)=>{               //this is for autherisation part
    let {id} = req.params;
    let listing = await Listing.findById(id);
    if(!listing.owner.equals(res.locals.currUser._id)){
        req.flash("error","you are not the owner of the listing");
        return res.redirect(`/listings/${id}`);
    }
   next();
};


module.exports.isReviewAuthor = async ( req,res,next)=>{               //this is for autherisation part
    let {id,reviewId} = req.params;
    let review = await Review.findById(reviewId);
    if(!review.author.equals(res.locals.currUser._id)){
        req.flash("error","you are not the owner of the Review");
        return res.redirect(`/listings/${id}`);
    }
   next();
};


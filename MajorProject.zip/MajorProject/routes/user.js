const express = require("express");
const router = express.Router();
const User = require("../models/user.js");
const wrapAsync = require("../utils/wrapAsync.js");
const passport = require("passport");
const {saveredirectUrl} =require("../middleware.js");
const userController = require("../controllers/users.js");


router
.route("/signup")
.get(userController.renderSignupForm)     //for signup form
.post(wrapAsync(userController.signup));   //for signup


router
.route("/login")
.get(userController.renderLoginForm)   //for loging form
.post(saveredirectUrl,                  //for  login
    passport.authenticate("local",{failureRedirect:"/login" ,failureFlash:true}),
    userController.login
 );

 //for logout
router.get("/logout",userController.logout)

module.exports = router;
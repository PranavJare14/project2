const express = require("express");
const router = express.Router({mergeParams : true});
const wrapAsync = require("../utils/wrapAsync.js");  //function for retrun status and message 
const ExpressError = require("../utils/ExpressError.js");  //error handler class
const Review = require("../models/review.js"); 
const Listing = require("../models/listing.js");  //for access listing model
const {isLoggedIn, isReviewAuthor} = require("../middleware.js");
const reviewController = require("../controllers/reviews.js")


//review post route
router.post("/",
    isLoggedIn,
    wrapAsync (reviewController.createReview));
  
  //delete review routs
  router.delete("/:reviewId", 
   isLoggedIn,
   isReviewAuthor,
    wrapAsync (reviewController.destroyReview));
  

  module.exports = router
const express = require("express");
const router = express.Router();
const wrapAsync = require("../utils/wrapAsync.js");  //function for retrun status and message 
const ExpressError = require("../utils/ExpressError.js");  //error handler class
const Listing = require("../models/listing.js");  //for access listing model
const {isLoggedIn, isowner} = require("../middleware.js");
const listingController = require("../controllers/listings.js");



router
.route("/")
.get(wrapAsync( listingController.index))  //Index Route
.post(isLoggedIn,
   // uplode.single("listing[image]"),
   wrapAsync( listingController.createListing));     //Create Route

//New Route
router.get("/new", isLoggedIn, listingController.renderNewForm);


router
.route("/:id")
.get( wrapAsync( listingController.showListing))  //Show Route
.put( isLoggedIn,                                    //Update Route
      isowner,       
      // uplode.single("listing[image]"),                
     wrapAsync (listingController.updateListing))
.delete( isLoggedIn,                               //delete route
        isowner,
     wrapAsync (listingController.destroyListing));


//Edit Route
router.get("/:id/edit",
  isLoggedIn,
  isowner,
   wrapAsync (listingController.renderEditForm));



module.exports = router;